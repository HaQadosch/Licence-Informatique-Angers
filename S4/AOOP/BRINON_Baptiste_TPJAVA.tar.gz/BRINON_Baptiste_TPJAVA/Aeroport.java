public class Aeroport{
  public static void main(String[] args){
    System.out.println(" j'ai pas eu le temps de terminer le TP \n");
  }
}
